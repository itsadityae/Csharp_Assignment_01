import React, { useState } from 'react';
import './App.css';
import { MedicineTableDemo } from './components/MedicineTable';
import NumberRootParent from './components/NumberRootParent';
import CityListboxParent from './components/CityListboxParent';
import CityManager from './components/CityManager';
import ColorChangeLabel from './components/ColorChangeLabel';

function App() {
  const [activeComponent, setActiveComponent] = useState('medicine');

  const renderComponent = () => {
    switch (activeComponent) {
      case 'medicine':
        return <MedicineTableDemo />;
      case 'numberRoot':
        return <NumberRootParent />;
      case 'cityListbox':
        return <CityListboxParent />;
      case 'cityManager':
        return <CityManager />;
      case 'colorChange':
        return <ColorChangeLabel />;
      default:
        return <MedicineTableDemo />;
    }
  };

  return (
    <div className="App">
      <h1>React Assignment Components</h1>
      
      <div className="navigation">
        <button onClick={() => setActiveComponent('medicine')}>
          1. Medicine Table
        </button>
        <button onClick={() => setActiveComponent('numberRoot')}>
          2. Number Root Calculator
        </button>
        <button onClick={() => setActiveComponent('cityListbox')}>
          3. City Listbox
        </button>
        <button onClick={() => setActiveComponent('cityManager')}>
          4. City Manager
        </button>
        <button onClick={() => setActiveComponent('colorChange')}>
          5. Color Change Label
        </button>
      </div>

      <div className="component-container">
        {renderComponent()}
      </div>
    </div>
  );
}

export default App;
