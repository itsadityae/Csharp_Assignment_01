import React from 'react';

// Listbox component that displays cities
const CityListbox = ({ cities, onCityChange }) => {
  return (
    <div>
      <h3>Select a City</h3>
      <select 
        size="5" 
        onChange={onCityChange}
        style={{ width: '200px', fontSize: '16px' }}
      >
        <option value="">-- Select City --</option>
        {cities.map((city, index) => (
          <option key={index} value={city}>
            {city}
          </option>
        ))}
      </select>
    </div>
  );
};

export default CityListbox;
