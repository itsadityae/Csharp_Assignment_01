import React from 'react';

// Medicine class definition
class Medicine {
  constructor(id, title, price, expiryDate) {
    this.id = id;
    this.Title = title;
    this.Price = price;
    this.ExpiryDate = expiryDate;
  }
}

// Component that displays Medicine products in a table
const MedicineTable = ({ products }) => {
  return (
    <div>
      <h2>Medicine Inventory</h2>
      <table border="1" cellPadding="10" cellSpacing="0">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Price</th>
            <th>Expiry Date</th>
          </tr>
        </thead>
        <tbody>
          {products && products.length > 0 ? (
            products.map((medicine) => (
              <tr key={medicine.id}>
                <td>{medicine.id}</td>
                <td>{medicine.Title}</td>
                <td>${medicine.Price}</td>
                <td>{medicine.ExpiryDate}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4">No medicines available</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

// Example usage with sample data
export const MedicineTableDemo = () => {
  const medicines = [
    new Medicine(1, 'Aspirin', 10.99, '2025-12-31'),
    new Medicine(2, 'Paracetamol', 5.99, '2026-06-30'),
    new Medicine(3, 'Ibuprofen', 12.50, '2025-09-15'),
    new Medicine(4, 'Amoxicillin', 25.00, '2026-03-20'),
    new Medicine(5, 'Vitamin C', 8.75, '2027-01-10'),
  ];

  return <MedicineTable products={medicines} />;
};

export { Medicine };
export default MedicineTable;
