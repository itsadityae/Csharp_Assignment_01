import React, { useState } from 'react';
import NumberRoot from './NumberRoot';

// Parent component that manages the number state and passes it to NumberRoot
const NumberRootParent = () => {
  const [number, setNumber] = useState(0);
  const [inputValue, setInputValue] = useState('');

  const handleButtonClick = () => {
    const num = parseFloat(inputValue);
    if (!isNaN(num) && num >= 0) {
      setNumber(num);
    } else {
      alert('Please enter a valid non-negative number');
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Number Root Calculator</h2>
      <div>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Enter a number"
        />
        <button onClick={handleButtonClick} style={{ marginLeft: '10px' }}>
          Calculate Root
        </button>
      </div>
      <div style={{ marginTop: '20px' }}>
        <NumberRoot number={number} />
      </div>
    </div>
  );
};

export default NumberRootParent;
