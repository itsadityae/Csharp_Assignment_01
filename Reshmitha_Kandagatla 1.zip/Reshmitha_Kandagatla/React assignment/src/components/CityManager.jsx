import React, { useState } from 'react';

// Component to add cities and display them in a list
const CityManager = () => {
  const [cities, setCities] = useState([]);
  const [cityInput, setCityInput] = useState('');

  const handleAddCity = () => {
    if (cityInput.trim() === '') {
      alert('Please enter a city name');
      return;
    }

    if (cities.length >= 5) {
      alert('You can only add up to 5 cities');
      return;
    }

    setCities([...cities, cityInput.trim()]);
    setCityInput('');
  };

  const handleDisplayCities = () => {
    // This will trigger a re-render showing the cities
    // The display is already handled in the render below
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>City Manager</h2>
      <div>
        <input
          type="text"
          value={cityInput}
          onChange={(e) => setCityInput(e.target.value)}
          placeholder="Enter city name"
          onKeyPress={(e) => e.key === 'Enter' && handleAddCity()}
        />
        <button onClick={handleAddCity} style={{ marginLeft: '10px' }}>
          Add City
        </button>
      </div>
      
      <div style={{ marginTop: '10px' }}>
        <p>Cities added: {cities.length}/5</p>
        <button onClick={handleDisplayCities}>Display Cities</button>
      </div>

      <div style={{ marginTop: '20px' }}>
        {cities.length > 0 ? (
          <ul>
            {cities.map((city, index) => (
              <li key={index}>{city}</li>
            ))}
          </ul>
        ) : (
          <p>No city available</p>
        )}
      </div>
    </div>
  );
};

export default CityManager;
