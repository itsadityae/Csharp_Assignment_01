import React from 'react';

// Component that displays a number and its square root
const NumberRoot = ({ number }) => {
  const root = Math.sqrt(number);
  
  return (
    <div>
      <h1>Number: {number}</h1>
      <h1>Square Root: {root.toFixed(2)}</h1>
    </div>
  );
};

export default NumberRoot;
