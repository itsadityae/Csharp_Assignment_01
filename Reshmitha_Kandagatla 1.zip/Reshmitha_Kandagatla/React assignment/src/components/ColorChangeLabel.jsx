import React, { Component } from 'react';

// Class component with label and button to change colors
class ColorChangeLabel extends Component {
  constructor(props) {
    super(props);
    this.state = {
      textColor: 'green',
      backgroundColor: 'yellow'
    };
  }

  handleColorChange = () => {
    this.setState({
      textColor: 'blue',
      backgroundColor: 'pink'
    });
  };

  render() {
    const labelStyle = {
      color: this.state.textColor,
      backgroundColor: this.state.backgroundColor,
      padding: '10px 20px',
      fontSize: '18px',
      fontWeight: 'bold',
      display: 'inline-block',
      marginBottom: '10px'
    };

    return (
      <div style={{ padding: '20px' }}>
        <h2>Color Change Component</h2>
        <div>
          <label style={labelStyle}>
            This is a styled label
          </label>
        </div>
        <div style={{ marginTop: '10px' }}>
          <button onClick={this.handleColorChange}>
            Change Colors
          </button>
        </div>
      </div>
    );
  }
}

export default ColorChangeLabel;
