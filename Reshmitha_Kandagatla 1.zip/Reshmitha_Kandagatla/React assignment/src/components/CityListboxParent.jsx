import React from 'react';
import CityListbox from './CityListbox';

// Parent component that passes cities array and event handler to CityListbox
const CityListboxParent = () => {
  const cities = [
    'New York',
    'Los Angeles',
    'Chicago',
    'Houston',
    'Phoenix',
    'Philadelphia',
    'San Antonio',
    'San Diego',
    'Dallas',
    'San Jose'
  ];

  const handleCityChange = (event) => {
    const selectedCity = event.target.value;
    if (selectedCity) {
      alert(`Selected City: ${selectedCity}`);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>City Selection</h2>
      <CityListbox cities={cities} onCityChange={handleCityChange} />
    </div>
  );
};

export default CityListboxParent;
