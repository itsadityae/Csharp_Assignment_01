# React Assignment

This project contains 5 React components as per the assignment requirements.

## Components Overview

### 1. Medicine Table Component
**Files:** 
- [src/components/MedicineTable.jsx](src/components/MedicineTable.jsx)

**Description:** 
- Displays an array of Medicine products in an HTML table
- Medicine class has properties: id, Title, Price, ExpiryDate
- Accepts products array as props

### 2. Number Root Calculator
**Files:**
- [src/components/NumberRoot.jsx](src/components/NumberRoot.jsx) - Child component that displays number and its square root
- [src/components/NumberRootParent.jsx](src/components/NumberRootParent.jsx) - Parent component with textbox and button

**Description:**
- `NumberRoot`: Takes a number as props and displays it along with its square root in `<h1>` elements
- `NumberRootParent`: Manages state for the number, takes input from textbox, and passes it to NumberRoot on button click

### 3. City Listbox Components
**Files:**
- [src/components/CityListbox.jsx](src/components/CityListbox.jsx) - Listbox component
- [src/components/CityListboxParent.jsx](src/components/CityListboxParent.jsx) - Parent component

**Description:**
- `CityListbox`: Function component that displays an HTML listbox (size=5) with city names. Accepts cities array and onChange event handler as props
- `CityListboxParent`: Passes the cities string array and event handler to CityListbox. Shows alert when a city is selected

### 4. City Manager Component
**Files:**
- [src/components/CityManager.jsx](src/components/CityManager.jsx)

**Description:**
- Takes city names from a textbox and stores them in state on button click
- Allows entering up to 5 cities, one by one
- Displays all cities in a `<ul>` list when the display button is clicked
- Shows "No city available" message if no cities are in state

### 5. Color Change Label Component
**Files:**
- [src/components/ColorChangeLabel.jsx](src/components/ColorChangeLabel.jsx)

**Description:**
- Class component that displays a label and a button
- Initial label styles: green text color, yellow background color
- On button click, changes to different colors (blue text, pink background) using inline styles

## Project Structure

```
React assignment/
├── src/
│   ├── components/
│   │   ├── MedicineTable.jsx
│   │   ├── NumberRoot.jsx
│   │   ├── NumberRootParent.jsx
│   │   ├── CityListbox.jsx
│   │   ├── CityListboxParent.jsx
│   │   ├── CityManager.jsx
│   │   └── ColorChangeLabel.jsx
│   ├── App.jsx
│   ├── App.css
│   ├── main.jsx
│   └── index.css
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## Setup and Installation

1. **Install Dependencies:**
   ```bash
   npm install
   ```

2. **Run Development Server:**
   ```bash
   npm run dev
   ```

3. **Build for Production:**
   ```bash
   npm run build
   ```

## How to Use

Once the development server is running:

1. Open your browser to the URL shown in the terminal (typically `http://localhost:5173`)
2. You'll see navigation buttons at the top to switch between different components
3. Click on any button to view and interact with that specific component

## Technologies Used

- React 18.2.0
- Vite 5.0.8 (Build tool)
- JavaScript (ES6+)

## Key Concepts Demonstrated

- **Props**: Passing data from parent to child components
- **State**: Managing component state with `useState` hook and class component state
- **Event Handlers**: Handling button clicks, text input changes, and select changes
- **Conditional Rendering**: Showing different UI based on state
- **Class Components**: Traditional React class component with lifecycle
- **Functional Components**: Modern React functional components with hooks
- **Lists and Keys**: Rendering lists with proper key props
- **Controlled Components**: Form inputs controlled by React state

## Author

Created as part of React assignment requirements.
