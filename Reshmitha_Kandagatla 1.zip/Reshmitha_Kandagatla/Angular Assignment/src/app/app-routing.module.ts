import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NumberComponent } from './number/number.component';
import { CountryCapitalComponent } from './country-capital/country-capital.component';
import { MedicineListComponent } from './medicine-list/medicine-list.component';
import { SourceComponent } from './source/source.component';
import { DestinationComponent } from './destination/destination.component';
import { PromiseObservableComponent } from './promise-observable/promise-observable.component';
import { WeatherComponent } from './weather/weather.component';
import { UsernameBindingComponent } from './username-binding/username-binding.component';
import { CounterComponent } from './counter/counter.component';
import { StyleClassComponent } from './style-class/style-class.component';
import { MedicineInfoComponent } from './medicine-info/medicine-info.component';

const routes: Routes = [
  { path: '', redirectTo: '/number', pathMatch: 'full' },
  { path: 'number', component: NumberComponent },
  { path: 'country-capital', component: CountryCapitalComponent },
  { path: 'medicine-list', component: MedicineListComponent },
  { path: 'source', component: SourceComponent },
  { path: 'destination/:id/:name/:email', component: DestinationComponent },
  { path: 'promise-observable', component: PromiseObservableComponent },
  { path: 'weather', component: WeatherComponent },
  { path: 'username-binding', component: UsernameBindingComponent },
  { path: 'counter', component: CounterComponent },
  { path: 'style-class', component: StyleClassComponent },
  { path: 'medicine-info', component: MedicineInfoComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
