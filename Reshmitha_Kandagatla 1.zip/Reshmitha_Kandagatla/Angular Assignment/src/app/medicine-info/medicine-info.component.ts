import { Component } from '@angular/core';
import { Info } from '../models/info.model';

@Component({
  selector: 'app-medicine-info',
  templateUrl: './medicine-info.component.html',
  styleUrls: ['./medicine-info.component.css']
})
export class MedicineInfoComponent {
  medicines: Info[] = [
    new Info('Cough Syrup', new Date(2021, 10, 21), 245),
    new Info('Pain Relief Gel', new Date(2024, 5, 15), 180),
    new Info('Vitamin Tablets', new Date(2025, 8, 30), 320),
    new Info('Eye Drops', new Date(2023, 11, 10), 150),
    new Info('Antiseptic Cream', new Date(2024, 3, 25), 95)
  ];
}
