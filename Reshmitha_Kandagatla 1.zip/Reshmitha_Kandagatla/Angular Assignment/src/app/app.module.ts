import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NumberComponent } from './number/number.component';
import { CountryCapitalComponent } from './country-capital/country-capital.component';
import { MedicineListComponent } from './medicine-list/medicine-list.component';
import { SourceComponent } from './source/source.component';
import { DestinationComponent } from './destination/destination.component';
import { PromiseObservableComponent } from './promise-observable/promise-observable.component';
import { WeatherComponent } from './weather/weather.component';
import { UsernameBindingComponent } from './username-binding/username-binding.component';
import { CounterComponent } from './counter/counter.component';
import { StyleClassComponent } from './style-class/style-class.component';
import { MedicineInfoComponent } from './medicine-info/medicine-info.component';
import { MedicineFilterPipe } from './pipes/medicine-filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    NumberComponent,
    CountryCapitalComponent,
    MedicineListComponent,
    SourceComponent,
    DestinationComponent,
    PromiseObservableComponent,
    WeatherComponent,
    UsernameBindingComponent,
    CounterComponent,
    StyleClassComponent,
    MedicineInfoComponent,
    MedicineFilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
