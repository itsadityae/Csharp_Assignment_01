export class Medicine {
  constructor(
    public name: string,
    public expiry: Date,
    public price: number,
    public category: string
  ) {}
}
