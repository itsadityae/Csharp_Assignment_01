export class Info {
  constructor(
    public name: string,
    public expiry: Date,
    public price: number
  ) {}
}
