export class Country {
  constructor(public country: string, public capital: string) {}
}
