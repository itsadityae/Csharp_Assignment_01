import { Component } from '@angular/core';

@Component({
  selector: 'app-style-class',
  templateUrl: './style-class.component.html',
  styleUrls: ['./style-class.component.css']
})
export class StyleClassComponent {
  paragraphStyles = {
    'background-color': 'red',
    'font-size': '26px'
  };

  isActive: boolean = true;
}
