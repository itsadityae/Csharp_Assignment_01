import { Component } from '@angular/core';
import { Weather } from '../models/weather.model';

@Component({
  selector: 'app-weather',
  templateUrl: './weather.component.html',
  styleUrls: ['./weather.component.css']
})
export class WeatherComponent {
  weatherData: Weather[] = [
    new Weather('Hot', 42, 28),
    new Weather('Moderate', 30, 18),
    new Weather('Cold', 15, 5),
    new Weather('Hot', 38, 25),
    new Weather('Moderate', 25, 15)
  ];

  selectedTemp: number = 0;

  selectMaxTemp(weather: Weather): void {
    this.selectedTemp = weather.maxTemp;
    weather.selectedTemp = weather.maxTemp;
  }
}
