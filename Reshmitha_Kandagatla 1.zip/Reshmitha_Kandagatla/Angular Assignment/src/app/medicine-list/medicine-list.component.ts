import { Component } from '@angular/core';
import { Medicine } from '../models/medicine.model';

@Component({
  selector: 'app-medicine-list',
  templateUrl: './medicine-list.component.html',
  styleUrls: ['./medicine-list.component.css']
})
export class MedicineListComponent {
  medicines: Medicine[] = [
    new Medicine('Paracetamol', new Date(2025, 5, 15), 50, 'Painkiller'),
    new Medicine('Cough Syrup', new Date(2024, 11, 20), 120, 'Cold'),
    new Medicine('Aspirin', new Date(2026, 2, 10), 80, 'Painkiller'),
    new Medicine('Vitamin C', new Date(2025, 8, 25), 200, 'Supplement'),
    new Medicine('Ibuprofen', new Date(2025, 4, 30), 95, 'Painkiller'),
    new Medicine('Antibiotic', new Date(2024, 10, 5), 350, 'Antibiotic'),
    new Medicine('Vitamin D', new Date(2026, 1, 18), 180, 'Supplement'),
    new Medicine('Nasal Spray', new Date(2025, 7, 12), 145, 'Cold'),
    new Medicine('Antacid', new Date(2025, 3, 22), 75, 'Digestive'),
    new Medicine('Multivitamin', new Date(2026, 6, 8), 250, 'Supplement')
  ];

  categoryFilter: string = '';
}
