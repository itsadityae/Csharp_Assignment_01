import { Component } from '@angular/core';

@Component({
  selector: 'app-username-binding',
  templateUrl: './username-binding.component.html',
  styleUrls: ['./username-binding.component.css']
})
export class UsernameBindingComponent {
  userName: string = '';
}
