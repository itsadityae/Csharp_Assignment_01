import { Component } from '@angular/core';
import { Country } from '../models/country.model';

@Component({
  selector: 'app-country-capital',
  templateUrl: './country-capital.component.html',
  styleUrls: ['./country-capital.component.css']
})
export class CountryCapitalComponent {
  countries: Country[] = [
    new Country('India', 'Delhi'),
    new Country('USA', 'Washington DC'),
    new Country('UK', 'London'),
    new Country('France', 'Paris'),
    new Country('Germany', 'Berlin'),
    new Country('Japan', 'Tokyo')
  ];

  selectedCapital: string = '';

  onCountryChange(event: any): void {
    this.selectedCapital = event.target.value;
  }
}
