import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-source',
  templateUrl: './source.component.html',
  styleUrls: ['./source.component.css']
})
export class SourceComponent {
  id: number = 101;
  name: string = 'John Doe';
  email: string = 'john.doe@example.com';

  constructor(private router: Router) {}

  sendToDestination(): void {
    this.router.navigate(['/destination', this.id, this.name, this.email]);
  }
}
