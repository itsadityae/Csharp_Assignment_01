import { Component } from '@angular/core';

@Component({
  selector: 'app-number',
  templateUrl: './number.component.html',
  styleUrls: ['./number.component.css']
})
export class NumberComponent {
  numbers: number[] = [10, 25, 37, 42, 58, 63, 74, 89, 91, 100];

  showNumber(num: number): void {
    alert(`The number is: ${num}`);
  }
}
