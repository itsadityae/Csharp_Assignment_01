import { Pipe, PipeTransform } from '@angular/core';
import { Medicine } from '../models/medicine.model';

@Pipe({
  name: 'medicineFilter'
})
export class MedicineFilterPipe implements PipeTransform {
  transform(medicines: Medicine[], category: string): Medicine[] {
    if (!category || category.trim() === '') {
      return medicines;
    }
    return medicines.filter(medicine => 
      medicine.category.toLowerCase().includes(category.toLowerCase())
    );
  }
}
