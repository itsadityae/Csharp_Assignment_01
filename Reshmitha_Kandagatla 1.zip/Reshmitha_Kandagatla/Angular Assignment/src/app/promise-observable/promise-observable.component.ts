import { Component } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

@Component({
  selector: 'app-promise-observable',
  templateUrl: './promise-observable.component.html',
  styleUrls: ['./promise-observable.component.css']
})
export class PromiseObservableComponent {
  promiseNumber: number | null = null;
  observableString: string = '';

  async getPromise(): Promise<number> {
    return new Promise<number>((resolve) => {
      setTimeout(() => {
        resolve(42);
      }, 1000);
    });
  }

  getObservable(): Observable<string> {
    return of('Hello from Observable!').pipe(delay(1000));
  }

  async handleButtonClick(): Promise<void> {
    // Get value from Promise using then
    this.getPromise().then(value => {
      this.promiseNumber = value;
    });

    // Get value from Observable using subscribe
    this.getObservable().subscribe(value => {
      this.observableString = value;
    });
  }
}
