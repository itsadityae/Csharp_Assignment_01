
export const environment = {
    NODE_APP_URL: 'https://reshmithaexpressapp123-bnayfvbdembehhbw.spaincentral-01.azurewebsites.net',
};