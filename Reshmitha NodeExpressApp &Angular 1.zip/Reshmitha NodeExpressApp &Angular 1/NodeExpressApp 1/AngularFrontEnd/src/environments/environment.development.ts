export const environment = {
    NODE_APP_URL: 'http://localhost:3001',
};