import { Observable } from "rxjs/internal/Observable";
import { customer, dto } from "./models";
import { HttpClient, HttpResponse } from "@angular/common/http";
import { environment } from "../../environments/environment.development";
import path from "path";
import { Injectable } from "@angular/core";

export abstract class abstarctHttpService{
    abstract getCities() : Observable<HttpResponse<dto>>;
    abstract getCustomersByCity(city:string) : Observable<HttpResponse<dto>>;
    abstract addCustomer(item:customer) : Observable<HttpResponse<dto>>;
    abstract updateCustomer(item :customer) : Observable<HttpResponse<dto>>;
    abstract deleteCustomer(id:string) : Observable<HttpResponse<dto>>;
}   

@Injectable()

export class httpService extends abstarctHttpService{
    

baseUrl!:string;

    constructor(private client:HttpClient){
        super();
        this.baseUrl = environment.NODE_APP_URL;
    }
    override getCities(): Observable<HttpResponse<dto>> {
        
        const path = `${this.baseUrl}/cities`;
        const response = this.client.get<dto>(path,{observe:'response'});
        return response;
    }
    override getCustomersByCity(city: string): Observable<HttpResponse<dto>> {
      
       const path = `${this.baseUrl}/customers/${city}`;
       const response = this.client.get<dto>(path,{observe:'response'});
       return response;
    }
    override addCustomer(item: customer): Observable<HttpResponse<dto>> {
        const path = `${this.baseUrl}/add`;
        const response = this.client.post<dto>(path,item,{observe:'response'});
        return response;

    }
    override updateCustomer(item: customer): Observable<HttpResponse<dto>> {
        const path = `${this.baseUrl}/update`;
        const response = this.client.put<dto>(path,item,{observe:'response'});
        return response;    
        
    }
    override deleteCustomer(id: string): Observable<HttpResponse<dto>> {
      const path= `${this.baseUrl}/delete?id=${id}`;
      const response = this.client.delete<dto>(path,{observe:'response'});
      return response;
    }
    
}