import { Component, signal, WritableSignal } from '@angular/core';
import { abstarctHttpService, httpService } from '../services/httpService';
import {RouterLink} from '@angular/router';
@Component({
  selector: 'app-city-component',
  imports: [RouterLink],
  templateUrl: './city-component.html',
  styleUrl: './city-component.css',
  providers:[{provide:abstarctHttpService,useClass:httpService  }]
})
export class CityComponent {
  cities:WritableSignal<string[]> = signal <string[]>([]);

  message:WritableSignal<string> = signal<string>('');

  constructor(private service:abstarctHttpService){}
    ngOnInit():void{
      this.fetchCities();
    }
  fetchCities():void{
    this.service.getCities().subscribe({
      next:(result)=>{
        const citylist = result.body?.data;
        this.cities.set(citylist );
      },
      error:(e:any)=>{
          this.message.set(e.error.message); } 

      });
  }
}
