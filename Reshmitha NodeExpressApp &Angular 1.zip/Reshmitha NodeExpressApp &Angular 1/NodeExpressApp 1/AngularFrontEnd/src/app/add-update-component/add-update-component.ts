import { Component, signal, WritableSignal } from '@angular/core';
import { abstarctHttpService, httpService } from '../services/httpService';
import { customer } from '../services/models';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-update-component',
  imports: [FormsModule],
  templateUrl: './add-update-component.html',
  styleUrls: ['./add-update-component.css'],
  providers:[{provide:abstarctHttpService,useClass:httpService}]
})
export class AddUpdateComponent {
  cust :customer;
  message:WritableSignal<string> = signal<string>('');
  constructor(private service:abstarctHttpService){
    this.cust = new customer();
  }
  
addCustomer():void{
  this.service.addCustomer(this.cust).subscribe({
    next:(result)=>{
      this.message.set(result.body?.message!);
    },
    error:(e:any)=>{this.message.set(e.message);}
  });
}
}
