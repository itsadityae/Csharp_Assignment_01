import { Component, signal, WritableSignal } from '@angular/core';
import { customer } from '../services/models';
import { abstarctHttpService, httpService } from '../services/httpService';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { error } from 'console';

@Component({
  selector: 'app-customers-component',
  imports: [RouterLink],
  templateUrl: './customers-component.html',
  styleUrl: './customers-component.css',
  providers:[{provide:abstarctHttpService,useClass:httpService}]
})
export class CustomersComponent {
 customers:WritableSignal<customer[]> = signal <customer[]>([]);
 message:WritableSignal<string> = signal<string>('');
  city:string = '';

 constructor(private activeRoute:ActivatedRoute,private service: abstarctHttpService){}

 ngOnInit():void{

  this.activeRoute.params.subscribe(routedata=>{
    const city = routedata['city'];
    this.city = city;
    //sessionStorage.setItem('city',city);
    this.getCustomers(city);
  });
 }
 getCustomers(city:string):void
 {
   this.service.getCustomersByCity(city).subscribe({
    next: (res: any) => {
      const customerlist = <customer[]>res.body?.data;
      this.customers.set(customerlist);
    },
    error: (e: any) => {
      this.message.set(e.error.message);
    }
   });
 }

 remove (id:string):void{
  const dialogResult = confirm('Delete Record?');

  if(dialogResult)
  {
  this.service.deleteCustomer(id).subscribe({
    next:(result)=>{this.message.set(result.body?.message!); 
      //this.getCustomers(sessionStorage.getItem('city')!);
      //sessionStorage.removeItem('city');
      this.getCustomers(this.city);
    },
    error:(e:any)=>{  this.message.set(e.message); }
 });
}
}
  
}

