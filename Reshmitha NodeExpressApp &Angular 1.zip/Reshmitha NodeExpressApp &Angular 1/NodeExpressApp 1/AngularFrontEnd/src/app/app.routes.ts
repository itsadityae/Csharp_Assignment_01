import { Routes } from '@angular/router';
import { HomeComponent } from './home-component/home-component';   
import {CustomersComponent} from './customers-component/customers-component';
import { AddUpdateComponent } from './add-update-component/add-update-component';
export const routes: Routes = [
{path:'',component:HomeComponent},
{path:'customers/:city',component:CustomersComponent},
{path:'addupdate',component:AddUpdateComponent}
];
