import { Collection, Db, DeleteResult, Filter, MongoClient, ObjectId } from "mongodb";
import { config } from "../config";
import { injectable } from "inversify";

export class customer{
    _id?:ObjectId | string;
    name:string  = "";
    email:string = "";
    phone:string = "";
    city:string = "";
}

export interface icustomerRepo{
    cities():Promise<string[]>;
    getCustomersByCity(city:string):Promise<customer[]>;
    deleteCustomer(id:string):Promise<number>;
    addCustomer(item:customer):Promise<boolean>;
    updateCustomer(item:customer):Promise<boolean>;
}
@injectable()
export class customerRepo implements icustomerRepo{

    client!:MongoClient;
    db!:Db;
    customers!:Collection<customer>;

    constructor(){
        this.client = new MongoClient(config.MongoCstring);

        this.client.connect().then(c=>{
            this.db = this.client.db(config.MongoDB);
            this.customers = this.db.collection(config.mongoCollection);
        });
    }

    async cities():Promise<string[]>{
        const result = await this.customers.distinct('city');
        return result;
    }

    async getCustomersByCity(city: string): Promise<customer[]> {
        const filter:Filter<customer>= {city:city};
        const result = await this.customers.find<customer>(filter).project<customer>({}).toArray();
        return result;
    }

    async deleteCustomer(id: string): Promise<number> {
        const filter:Filter<customer> = {_id: new ObjectId(id)};
        const result:DeleteResult = await this.customers.deleteOne(filter);
        return result.deletedCount;
    }

    async addCustomer(item: customer): Promise<boolean> {
        delete item._id;
        const result = await this.customers.insertOne(item);
        return result.acknowledged;
    }

    async updateCustomer(item: customer): Promise<boolean> {
        const filter:Filter<customer> = {_id: new ObjectId(item._id)};
        const update = {$set: {name:item.name, email:item.email, phone:item.phone, city:item.city}};
        const result = await this.customers.updateOne(filter, update);
        return result.modifiedCount==1 ? true : false;
    }
}