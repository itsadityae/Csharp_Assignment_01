
import "reflect-metadata";
import { Container } from "inversify";

import { TYPES } from "./types";
import { customerRepo, icustomerRepo } from "./repository/customerRepo";
import { customerController } from "./controller/customerController";
import { customerService, icustomerService } from "./services/customerService";

const container = new Container({ defaultScope:"Singleton" });

// Bind interfaces to implementations
container.bind<icustomerRepo>(TYPES.customerRepo).to(customerRepo);
container.bind<icustomerService>(TYPES.customerService).to(customerService);
container.bind<customerController>(TYPES.customerController).to(customerController);

export { container };

