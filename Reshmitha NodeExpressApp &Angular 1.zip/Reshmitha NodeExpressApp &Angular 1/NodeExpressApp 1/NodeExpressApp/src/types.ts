
export const TYPES = {
  customerRepo: Symbol.for("customerRepo"),
  customerService: Symbol.for("customerService"),
  customerController: Symbol.for("customerController")
};
