import express from "express";
//import { productController } from "./controller/productController";
import { config } from "./config";
//import { container } from "./container";
import { TYPES } from "./types";
import cors from 'cors'; // Import the cors middleware
import { container } from "./container";
import { customerController } from "./controller/customerController";
import { Request, Response } from "express";
const app= express();
app.use(express.json());

const ANGULARAPP_URL=config.AngularAppURL

const corsOptions = {
  origin: ANGULARAPP_URL, // Update this to your Angular URL
  methods: 'GET,POST,PUT,DELETE,OPTIONS',
  allowedHeaders: 'Content-Type,Authorization'
};

const controller = container.get<customerController>(TYPES.customerController);

app.use(cors(corsOptions));

app.get('/',(req:Request, res:Response)=>{
    res.status(200).json({message:'Welcome to REST Service.'})
})

app.get('/cities', controller.cities);

app.get('/customers/:city', controller.findByCity);

app.delete('/delete', controller.deleteCustomer);

app.post('/add',controller.add);

app.put('/update',controller.update);

app.listen(config.Port,()=> console.log(`Express Server listening on port ${config.Port}`));
