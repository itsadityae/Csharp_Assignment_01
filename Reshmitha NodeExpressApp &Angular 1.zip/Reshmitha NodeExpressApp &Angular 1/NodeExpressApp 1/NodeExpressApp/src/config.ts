
export class config{
  static Port=process.env.PORT || 3001
  static MongoDB= process.env.MONGODB || "CustomerDbase"
  static mongoCollection= process.env.MONGOCOLLECTION || "customers"
  static MongoCstring = process.env.MONGO_CONNECTIONSTRING || "mongodb://localhost:27017"
  static AngularAppURL=process.env.ANGULAR_APP_URL || "http://localhost:4200"  
}