import { inject, injectable } from "inversify";
import { customer, icustomerRepo } from "../repository/customerRepo";
import { TYPES } from "../types";

export interface icustomerService{
    allcities():Promise<string[]>;
    findByCity(city:string):Promise<customer[]>;
    add(item:customer):Promise<boolean>;
    update(item:customer):Promise<boolean>;
    delete(id:string):Promise<boolean>;
}

@injectable()
export class customerService implements icustomerService{

    constructor(@inject(TYPES.customerRepo)  private repo:icustomerRepo){}

    async allcities(): Promise<string[]>{
        const cities = await this.repo.cities();
        return cities;
    }
    async findByCity(city: string): Promise<customer[]> {
        const customers:customer[] =await this.repo.getCustomersByCity(city);
        return customers;
    }
    async add(item:customer):Promise<boolean>{
        const result = await this.repo.addCustomer(item);
        return result;
    }
    async delete(id:string):Promise<boolean>{
        const result:number = await this.repo.deleteCustomer(id);
        return result==1?true:false;
    }
    async update(item: customer):Promise<boolean>{
        const result = await this.repo.updateCustomer(item);
        return result;
    }
}