import { Request, Response } from "express";
import { icustomerService } from "../services/customerService";
import { dto } from "../dto";
import { inject, injectable } from "inversify";
import { TYPES } from "../types";

@injectable()
export class customerController{
    constructor(@inject(TYPES.customerService) private service:icustomerService){}

    cities = async (req:Request, res:Response) => {
        let _dto = new dto();
        try{
            const cities = await this.service.allcities();
            _dto.success = true;
            _dto.data = cities;
            res.status(200).json(_dto);
        }
        catch(e:any){
            _dto.message = e.message;
            _dto.success = false;
            res.status(500).json(_dto);
        }
    }

    findByCity = async (req:Request, res:Response)=>{
        let dt = new dto();
        try{
            const result = await this.service.findByCity(req.params.city.toString());
            dt.data = result;
            dt.success = true;
            res.status(200).json(dt);
        }
        catch(e:any){
            dt.message = e.message;
            dt.success = false;
            res.status(500).json(dt);
        }
    }

    deleteCustomer = async (req:Request, res:Response)=>{
        const dt = new dto();
        try{
            const id = req.query.id?.toString();
            const result = await this.service.delete(id!);
            if(result){
                dt.message = "Deleted"; dt.success = true;
            }
            else{
                dt.message = "Not Deleted"; dt.success = false;
            }
            res.status(200).json(dt);
        }
        catch(e:any){
            dt.message = e.message;
            dt.success = false;
            res.status(500).json(dt);
        }
    }

    add = async(req:Request, res:Response)=>{
        let dt = new dto();
        try{
            const result = await this.service.add(req.body);
            if(result){dt.message="Added"; dt.success=true;}
            else{dt.message="Not Added"; dt.success=false;}
            res.status(200).json(dt);
        }
        catch(e:any){
            dt.message = e.message;
            dt.success = false;
            res.status(500).json(dt);
        }
    }

    update = async(req:Request, res:Response)=>{
        let dt = new dto();
        try{
            const result = await this.service.update(req.body);
            if(result){dt.message="Updated"; dt.success=true;}
            else{dt.message="Not Updated"; dt.success=false;}
            res.status(200).json(dt);
        }
        catch(e:any){
            dt.message = e.message;
            dt.success = false;
            res.status(500).json(dt);
        }
    }
}