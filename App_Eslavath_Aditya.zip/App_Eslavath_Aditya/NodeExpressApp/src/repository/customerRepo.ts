import { Collection, Db, DeleteResult, Filter, MongoClient, ObjectId } from "mongodb";
import { config } from "../config";
import { inject, injectable } from "inversify";

export class customer{
    _id?:ObjectId | string;
    name:string='';
    email:string='';
    phone:string='';
    city:string=''  ;
}


export interface icustomerRepo{
    cities():Promise<string[]>;
    getCustomersByCity(city:string):Promise<customer[]>;
    deleteCustomer(id:string):Promise<number>;
    addCustomer(customer:customer):Promise<boolean>;
    updateCustomer(item:customer):Promise<boolean>;
}

@injectable()
    
export class customerRepo implements icustomerRepo{

    client!:MongoClient; 
    db!:Db;
    customers!:Collection<customer>;

    constructor(){
        
        this.client=new MongoClient(config.MongoCString);
        this.client.connect().then(c=>{
        this.db=this.client.db(config.MongoDB);
        this.customers=this.db.collection(config.MongoCollection);

        });
    }


    async updateCustomer(item: customer): Promise<boolean> {
        // throw new Error("Method not implemented.");
        const filter:Filter<customer>={_id:new ObjectId(item._id)};
        const update={$set:{name:item.name,email:item.email,phone:item.phone,city:item.city}};
        const result= await this.customers.updateOne(filter,update);
        return result.modifiedCount==1? true:false;
    }


    async cities(): Promise<string[]> {
        // throw new Error("Method not implemented.");
        const result = await this.customers.distinct("city");
        return result;
    }

    async getCustomersByCity(city: string): Promise<customer[]> {
        // throw new Error("Method not implemented.");
        const filter:Filter<customer>={city:city};
        const result = await this.customers.find<customer>(filter).project<customer>({}).toArray();
        return result;
    }

    async deleteCustomer(id: string): Promise<number> {
        // throw new Error("Method not implemented.");\
        const filter:Filter<customer>={_id:new ObjectId(id)};
        const result:DeleteResult= await this.customers.deleteOne(filter);
        return result.deletedCount;
    }

    async addCustomer(item: customer): Promise<boolean> {
        // throw new Error("Method not implemented.");
        delete item._id;
        const result= await this.customers.insertOne(item);
        return result.acknowledged;
    }
}
