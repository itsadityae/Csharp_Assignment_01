export const TYPES = {
  customerRepo: Symbol.for("customerRepo"),
  customerController: Symbol.for("customerController"),
  customerService: Symbol.for("customerService")
};
