import { Request, Response } from "express";
import { icustomerService } from "../services/customerService";
import { dto } from "../dto";
import { inject, injectable } from "inversify";
import { TYPES } from "../types";

@injectable()
export class customerController {
    
    constructor(@inject(TYPES.customerService) private service: icustomerService){}
        cities = async (req:Request, res:Response) => {

            let _dto=new dto();
            try{
                const cities = await this.service.allcities();
                _dto.success = true;
                _dto.data = cities;
                res.status(200).json(_dto);
            }
            catch(e:any){
                _dto.success = false;
                _dto.message = e.message;
                res.status(500).json(_dto);
            }
        
        }

    findByCity = async (req:Request, res:Response) => {

        let dt=new dto();
        try{
            const result = await this.service.findByCity(req.params.city.toString());
            dt.success = true;
            dt.data = result;
            res.status(200).json(dt);

        }
        catch(e:any){
            dt.success = false;
            dt.message = e.message;
            res.status(500).json(dt);
        }
    }

    deleteCustomer = async (req:Request, res:Response) => {
        const dt = new dto();
        try{
            const id = req.query.id?.toString();
            const result = await this.service.delete(id!);

            if(result){
                dt.success = true;
                dt.message = "Customer deleted successfully";
                // res.status(200).json(dt);
            }
            else{
                dt.success = false;
                dt.message = "Customer not deleted";
                // res.status(404).json(dt);
            }
        }
        catch(e:any){
            dt.success = false;
            dt.message = e.message;
            res.status(500).json(dt);
        }
    }

    add = async (req:Request, res:Response) => {
        let dt = new dto();
        try{
            //fetch the customer data from the request body and pass it to the service layer
            const result = await this.service.add(req.body); 
            if(result){
                dt.success = true;
                dt.message = "Customer added successfully";
                // res.status(200).json(dt);
            }
            else{
                dt.success = false;
                dt.message = "Customer not added";
                // res.status(400).json(dt);
            }
            res.status(200).json(dt);
        }
        catch(e:any){
            dt.success = false;
            dt.message = e.message;
            res.status(500).json(dt);
        }
    }

    update = async (req:Request, res:Response) => {
        let dt = new dto();
        try{
            //fetch the customer data from the request body and pass it to the service layer
            const result = await this.service.update(req.body);
            if(result){
                dt.success = true;
                dt.message = "Customer updated successfully";
                // res.status(200).json(dt);
            }  
            else{
                dt.success = false;
                dt.message = "Customer not updated";
                // res.status(400).json(dt);
            }
            res.status(200).json(dt);
        }
        catch(e:any){
            dt.success = false;
            dt.message = e.message;
            res.status(500).json(dt);
        }
    }
}