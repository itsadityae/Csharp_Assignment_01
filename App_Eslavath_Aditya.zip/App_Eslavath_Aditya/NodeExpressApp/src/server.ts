import express from "express";
//import { productController } from "./controller/productController";
import { config } from "./config";
//import { container } from "./container";
import { TYPES } from "./types";
import cors from 'cors'; // Import the cors middleware
import { customerController } from "./controller/customerController";
import { container } from "./container";
import { Request, Response } from "express";
const app= express();
app.use(express.json());

const ANGULARAPP_URL=config.AngularAppURL

const corsOptions = {
  origin: ANGULARAPP_URL, // Update this to your Angular URL
  methods: 'GET,POST,PUT,DELETE,OPTIONS',
  allowedHeaders: 'Content-Type,Authorization'
};

const controller = container.get<customerController>(TYPES.customerController);

app.use(cors(corsOptions));

app.get('/',(req:Request,res:Response) => {
    res.status(200).json({message: "Welcome to the Rest service"});
});

app.get('/cities', controller.cities);// Define the route for fetching cities

app.get('/customers/:city', controller.findByCity);// Define the route for fetching customers by city

app.delete('/delete', controller.deleteCustomer);// Define the route for deleting a customer by id

app.put('/update', controller.update);// Define the route for updating a customer

app.post('/add', controller.add);// Define the route for adding a customer

app.listen(config.Port,()=> console.log(`Express Server listening on port ${config.Port}`));
