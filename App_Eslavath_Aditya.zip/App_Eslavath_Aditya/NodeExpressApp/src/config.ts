
export class config{
  static Port=process.env.PORT || 3001
  static MongoDB=process.env.MONGODB || "customerDbase"
  static MongoCollection=process.env.MONGOCOLLECTION || "customers"
  static MongoCString=process.env.MONGO_CONNECTIONSTRING || "mongodb://localhost:27017"
  static AngularAppURL=process.env.ANGULAR_APP_URL || "http://localhost:4200"

}

