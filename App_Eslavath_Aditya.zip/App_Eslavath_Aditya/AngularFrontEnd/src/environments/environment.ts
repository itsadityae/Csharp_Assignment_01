//configuration for production environment
// later the backend url will be changed to the actual url where the backend is hosted --> Cosmos DB, Azure Functions, etc.

export const environment = {
        NODE_APP_URL: "https://adityanodeexpressapp.azurewebsites.net" //backend url

};
