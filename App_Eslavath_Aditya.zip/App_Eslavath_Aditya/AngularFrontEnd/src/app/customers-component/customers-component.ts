import { Component, signal, WritableSignal } from '@angular/core';
import { customer } from '../services/models';
import { abstractHttpService, httpService } from '../services/httpService';
import { ActivatedRoute, RouterLink } from '@angular/router';

@Component({
  selector: 'app-customers-component',
  imports: [RouterLink],
  templateUrl: './customers-component.html',
  styleUrl: './customers-component.css',
  providers: [{provide: abstractHttpService, useClass: httpService}]
})
export class CustomersComponent {
  customers: WritableSignal<customer[]> = signal<customer[]>([]);
  message: WritableSignal<string> = signal<string>('');
  city: string = '';

  constructor(private service: abstractHttpService, private activeRoute: ActivatedRoute){}
  ngOnInit() {
    this.activeRoute.params.subscribe(routedata =>{
    // whenerver change occurs, we subscribe to it
      const city = routedata['city'];
      this.city = city;
      // sessionStorage.setItem('city', city);
      this.getCustomers(city);
    });
  }

  getCustomers(city: string): void {
    this.service.getCustomersByCity(city).subscribe({
      next:(res)=>{
        const customerlist = <customer[]>res.body?.data;
        this.customers.set(customerlist);
      },
      error:(e:any)=>{this.message.set(e.message)}
    });
  }

  remove(id:string): void {
    const dialogResult = confirm('Are you sure you want to delete this customer?');
    if (dialogResult == true) {
      this.service.deleteCustomer(id).subscribe({
        next:(result)=>{this.message.set(result.body?.message!);
          this.getCustomers(this.city);
          // sessionStorage.removeItem('city');
        },
        error:(e:any)=>{this.message.set(e.message);}
      });
    }
  }
}
