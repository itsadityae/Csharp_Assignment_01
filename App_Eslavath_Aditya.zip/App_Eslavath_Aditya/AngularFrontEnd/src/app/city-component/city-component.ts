import { Component, signal, WritableSignal } from '@angular/core';
import { abstractHttpService, httpService } from '../services/httpService';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-city-component',
  imports: [RouterLink],
  templateUrl: './city-component.html',
  styleUrl: './city-component.css',
  providers: [{provide: abstractHttpService, useClass: httpService}]
})
export class CityComponent {

  cities: WritableSignal<string[]> = signal<string[]>([]); //this is the signal which will hold the list of cities which will be fetched from the api and will be used to display the cities in the dropdown.
  
  message: WritableSignal<string> = signal<string>(''); //this is the signal which will hold the message which will be displayed in the alert box when the user clicks on the delete button.

  constructor(private service: abstractHttpService) {}

  ngOnInit() {
    this.fetchCities(); //this is to fetch the cities from the api when the component is initialized.
  }
  fetchCities():void{
    this.service.getCities().subscribe({
      next: (result) => {
        const Citylist = result.body?.data;
        this.cities.set(Citylist) //this is to get the list of cities from the response body and if the body is undefined then we will set it to an empty array.
      },
      error: (e) => {
        this.message.set(e.message); //this is to set the message in case of error while fetching the cities from the api.
      }
    });
  }
}
