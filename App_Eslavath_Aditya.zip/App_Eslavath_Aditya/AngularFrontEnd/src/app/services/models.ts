// dto

//dto helps to send data in a specific format to the client with every response. It can be used to standardize the response format and make it easier for the client to handle the responses.
export class dto{
 
    message:string='';
    success:boolean=false;
    data!:any;
 
    constructor(msg?:string,_success?:boolean,_data?:any){
        this.message=msg || "";
        this.success=_success || false;
        this.data=_data || undefined;
    }
}
 
 
// customer model
export class customer{
    _id?: string;
    name:string='';
    email:string='';
    phone:string='';
    city:string='';
}