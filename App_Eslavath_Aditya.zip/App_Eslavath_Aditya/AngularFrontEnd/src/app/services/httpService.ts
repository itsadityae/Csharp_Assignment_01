import { HttpClient, HttpResponse } from "@angular/common/http";
import { Observable } from "rxjs";
import { customer, dto } from "./models";
import { environment } from "../../environments/environment";
import { Inject, inject, Injectable } from "@angular/core";

//from angular application these will be the services which will be called to perform the http operations. These are abstract classes which will be implemented in the actual service class. 


export abstract class abstractHttpService{
    abstract getCities():Observable<HttpResponse<dto>>;
    abstract getCustomersByCity(city: string):Observable<HttpResponse<dto>>;
    abstract deleteCustomer(id: string):Observable<HttpResponse<dto>>;
    abstract addCustomer(item: customer):Observable<HttpResponse<dto>>;
    abstract updateCustomer(item: customer):Observable<HttpResponse<dto>>;
    
}

//we want the http client to use the fetch library...

@Injectable()

export class httpService extends abstractHttpService{
    
    baseUrl!: string; //this is the base url for the api calls which will be set in the constructor.

    constructor(private client: HttpClient) { //this is for the dependency injection of the http client which will be used to make the http calls.
        super();
        this.baseUrl = environment.NODE_APP_URL; //setting the base url from the environment variable which is defined in the environment file.

    }
    
    override getCities(): Observable<HttpResponse<dto>> {
        // throw new Error("Method not implemented.");
        const path = `${this.baseUrl}/cities`; //in the node express app we have defined the route for getting the cities as /cities so we are using that route here to make the http call.

        const response = this.client.get<dto>(path, { observe: 'response' }); //making the http get call to the api and observing the response to get the full response including the status code and headers.

        return response; //returning the response which is an observable of HttpResponse<dto>.
    }

    override getCustomersByCity(city: string): Observable<HttpResponse<dto>> {
        // throw new Error("Method not implemented.");
        const path = `${this.baseUrl}/customers/${city}`; 
        const response = this.client.get<dto>(path, { observe: 'response' });
        return response;
    }

    override deleteCustomer(id: string): Observable<HttpResponse<dto>> {
        // throw new Error("Method not implemented.");
        // check controller and server
        const path = `${this.baseUrl}/delete?id=${id}`; 
        const response = this.client.delete<dto>(path, { observe: 'response' });
        return response;
    }
    override addCustomer(item: customer): Observable<HttpResponse<dto>> {
        // throw new Error("Method not implemented.");
        const path = `${this.baseUrl}/add`;
        const response = this.client.post<dto>(path, item, { observe: 'response' });
        return response;
    }
    override updateCustomer(item: customer): Observable<HttpResponse<dto>> {
        // throw new Error("Method not implemented.");
        const path = `${this.baseUrl}/update`;
        const response = this.client.put<dto>(path, item, { observe: 'response' });
        return response;
    }

//     do check all this from 
//     app.get('/cities', controller.cities);// Define the route for fetching cities

// app.get('/customers/:city', controller.findByCity);// Define the route for fetching customers by city

// app.delete('/delete', controller.deleteCustomer);// Define the route for deleting a customer by id

// app.put('/update', controller.update);// Define the route for updating a customer

// app.post('/add', controller.add);// Define the route for adding a customer

// app.listen(config.Port,()=> console.log(`Express Server listening on port ${config.Port}`));

}