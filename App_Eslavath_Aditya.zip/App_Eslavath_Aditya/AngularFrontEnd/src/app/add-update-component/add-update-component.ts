import { Component, signal, WritableSignal } from '@angular/core';
import { customer } from '../services/models';
import { abstractHttpService, httpService } from '../services/httpService';
import { FormsModule } from '@angular/forms';
  
@Component({
  selector: 'app-add-update-component',
  imports: [FormsModule],
  templateUrl: './add-update-component.html',
  styleUrl: './add-update-component.css',
  providers: [{provide: abstractHttpService, useClass: httpService}]
})
export class AddUpdateComponent {
  cust: customer;
  message: WritableSignal<string>=signal<string>("");
  constructor(private service: abstractHttpService) {
    this.cust = new customer();
  }


  addCustomer(): void{
    this.service.addCustomer(this.cust).subscribe({
      next:(result)=>{
        this.message.set(result.body?.message!);
      },
      error:(e)=>{this.message.set(e.message);}
    })
  }

  
}
